#ifndef RECURSIVE_FILTER_H      //guard changes
#define RECURSIVE_FILTER_H 1 

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>

//any typedefs

//any function signatures

#endif